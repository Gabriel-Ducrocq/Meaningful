# TODO
- Running on GCP
- Remettre matplotlib
- S'occuper de la dataviz: implement matplotlib with 
https://stackoverflow.com/questions/47077563/import-tkinter-in-google-cloudplatforms
- Mettre les comments d'input et de output de chaque file, ainsi que les rôles

# DONE
- AttributeError: module 'datetime' has no attribute 'now': Potentiellement, ce n'est pas le bon module datetime qui 
    est importé.
- Reprendre les morceaux de code petit à petit
- Mettre en place tf.app.run()
- S'occuper des flags qui doivent passer en params pour que model puisse les executer